import React, { useState, useEffect } from 'react';
import {
    Box,
    Button,
    Card,
    CardContent,
    Grid,
    TextField,
    Typography,
    MenuItem,
    Divider,
    Stack,
    Autocomplete,
    Chip,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    IconButton,
    Tooltip,
    FormControl,
    InputLabel,
    Select,
    Accordion,
    AccordionSummary,
    AccordionDetails
} from '@mui/material';
import {
    Save as SaveIcon,
    ArrowBack as ArrowBackIcon,
    Delete as DeleteIcon,
    Add as AddIcon,
    Receipt as ReceiptIcon,
    ExpandMore as ExpandMoreIcon
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import { useSnackbar } from 'notistack';
import patientAPI from '../../../services/patientAPI';
import api from '../../../services/api';

const PatientForm = () => {
    const { t } = useTranslation();
    const navigate = useNavigate();
    const { id } = useParams();
    const { enqueueSnackbar } = useSnackbar();

    const isEdit = Boolean(id);
    const [loading, setLoading] = useState(false);

    const [formData, setFormData] = useState({
        name: '',
        date_of_birth: '',
        gender: 'M',
        phone: '',
        email: '',
        address: '',
        blood_type: '',
        allergies: '',
        chronic_conditions: '',
        emergency_contact_name: '',
        emergency_contact_phone: '',
    });

    // Services facturables state
    const [availableServices, setAvailableServices] = useState([]);
    const [selectedServices, setSelectedServices] = useState([]);
    const [paymentMethod, setPaymentMethod] = useState('cash');
    const [loadingServices, setLoadingServices] = useState(false);

    useEffect(() => {
        if (isEdit) {
            fetchPatient();
        }
        // Fetch available services/products for billing
        fetchServices();
    }, [id]);

    const fetchServices = async () => {
        try {
            setLoadingServices(true);
            // Fetch services/products from products API
            const response = await api.get('/products/', {
                params: {
                    product_type: 'service',
                    is_active: true,
                    page_size: 100
                }
            });
            const services = response.data.results || response.data || [];
            setAvailableServices(services);
        } catch (error) {
            console.error('Error fetching services:', error);
        } finally {
            setLoadingServices(false);
        }
    };

    const fetchPatient = async () => {
        try {
            setLoading(true);
            const data = await patientAPI.getPatient(id);
            setFormData({
                name: data.name || '',
                date_of_birth: data.date_of_birth || '',
                gender: data.gender || 'M',
                phone: data.phone || '',
                email: data.email || '',
                address: data.address || '',
                blood_type: data.blood_type || '',
                allergies: data.allergies || '',
                chronic_conditions: data.chronic_conditions || '',
                emergency_contact_name: data.emergency_contact_name || '',
                emergency_contact_phone: data.emergency_contact_phone || '',
            });
        } catch (error) {
            console.error('Error fetching patient:', error);
            enqueueSnackbar(t('common.error'), { variant: 'error' });
        } finally {
            setLoading(false);
        }
    };

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        // Basic validation
        if (!formData.name || !formData.date_of_birth) {
            enqueueSnackbar(t('validation.required_fields'), { variant: 'warning' });
            return;
        }

        // NOUVEAU: Validation téléphone obligatoire pour les patients
        if (!formData.phone || !formData.phone.trim()) {
            enqueueSnackbar('Le numéro de téléphone est obligatoire pour les patients', { variant: 'warning' });
            return;
        }

        setLoading(true);
        try {
            if (isEdit) {
                await patientAPI.updatePatient(id, formData);

                // Create invoice for selected services if any
                if (selectedServices.length > 0) {
                    try {
                        const invoiceResponse = await patientAPI.createQuickInvoice(id, {
                            service_ids: selectedServices.map(s => s.id),
                            payment_method: paymentMethod
                        });
                        enqueueSnackbar(`Patient mis à jour et facture créée: ${invoiceResponse.invoice_number}`, { variant: 'success' });
                        // Redirect to invoice page
                        navigate(`/invoices/${invoiceResponse.invoice_id}`);
                        return;
                    } catch (invoiceError) {
                        console.error('Error creating invoice:', invoiceError);
                        enqueueSnackbar('Patient mis à jour mais erreur lors de la création de la facture', { variant: 'warning' });
                    }
                } else {
                    enqueueSnackbar(t('patients.update_success', 'Patient mis à jour avec succès'), { variant: 'success' });
                }

                navigate('/healthcare/patients');
            } else {
                const response = await patientAPI.createPatient(formData);

                // Create invoice for selected services if any
                if (selectedServices.length > 0) {
                    try {
                        const invoiceResponse = await patientAPI.createQuickInvoice(response.id, {
                            service_ids: selectedServices.map(s => s.id),
                            payment_method: paymentMethod
                        });
                        enqueueSnackbar(`Patient créé avec succès et facture ${invoiceResponse.invoice_number} générée (${invoiceResponse.total_amount} FCFA)`, { variant: 'success' });
                        // Redirect to invoice page
                        navigate(`/invoices/${invoiceResponse.invoice_id}`);
                        return;
                    } catch (invoiceError) {
                        console.error('Error creating invoice:', invoiceError);
                        enqueueSnackbar('Patient créé mais erreur lors de la création de la facture', { variant: 'warning' });
                    }
                } else {
                    enqueueSnackbar(t('patients.create_success', 'Patient créé avec succès'), { variant: 'success' });
                }

                // Redirect to patient detail page after creation (only if no invoice was created)
                navigate(`/healthcare/patients/${response.id}`);
            }
        } catch (error) {
            console.error('Error saving patient:', error);
            // Show more specific error message if available
            const errorMessage = error.response?.data?.detail || error.response?.data?.non_field_errors?.[0] || t('common.error_saving');
            enqueueSnackbar(errorMessage, { variant: 'error' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <Box component="form" onSubmit={handleSubmit} noValidate>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3, alignItems: 'center' }}>
                <Stack direction="row" spacing={1} alignItems="center">
                    <Button startIcon={<ArrowBackIcon />} onClick={() => navigate('/healthcare/patients')}>
                        {t('common.back', 'Retour')}
                    </Button>
                    <Typography variant="h4" component="h1" sx={{ fontWeight: 600 }}>
                        {isEdit ? t('patients.edit', 'Modifier Patient') : t('patients.new', 'Nouveau Patient')}
                    </Typography>
                </Stack>
                <Button
                    type="submit"
                    variant="contained"
                    startIcon={<SaveIcon />}
                    disabled={loading}
                    sx={{ borderRadius: 2 }}
                >
                    {t('common.save', 'Enregistrer')}
                </Button>
            </Box>

            <Card sx={{ borderRadius: 3, mb: 3 }}>
                <CardContent sx={{ p: 4 }}>
                    <Typography variant="h6" gutterBottom color="primary">Information Personnelle</Typography>
                    <Divider sx={{ mb: 3 }} />

                    <Grid container spacing={3}>
                        <Grid item xs={12}>
                            <TextField
                                required
                                fullWidth
                                label={t('patients.full_name', 'Nom complet')}
                                name="name"
                                value={formData.name}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                required
                                fullWidth
                                type="date"
                                label={t('patients.dob', 'Date de Naissance')}
                                name="date_of_birth"
                                value={formData.date_of_birth}
                                onChange={handleChange}
                                InputLabelProps={{ shrink: true }}
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                select
                                fullWidth
                                label={t('patients.gender', 'Sexe')}
                                name="gender"
                                value={formData.gender}
                                onChange={handleChange}
                            >
                                <MenuItem value="M">Masculin</MenuItem>
                                <MenuItem value="F">Féminin</MenuItem>
                            </TextField>
                        </Grid>
                    </Grid>

                    <Typography variant="h6" gutterBottom color="primary" sx={{ mt: 4 }}>Coordonnées</Typography>
                    <Divider sx={{ mb: 3 }} />

                    <Grid container spacing={3}>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                required
                                label={t('patients.phone', 'Téléphone')}
                                name="phone"
                                value={formData.phone}
                                onChange={handleChange}
                                helperText="Obligatoire pour les patients"
                            />
                        </Grid>
                        <Grid item xs={12} sm={6}>
                            <TextField
                                fullWidth
                                label={t('patients.email', 'Email')}
                                name="email"
                                type="email"
                                value={formData.email}
                                onChange={handleChange}
                            />
                        </Grid>
                        <Grid item xs={12}>
                            <TextField
                                fullWidth
                                label={t('patients.address', 'Adresse')}
                                name="address"
                                value={formData.address}
                                onChange={handleChange}
                                multiline
                                rows={2}
                            />
                        </Grid>
                    </Grid>

                    <Accordion
                        elevation={0}
                        sx={{
                            '&:before': { display: 'none' },
                            backgroundColor: 'transparent',
                            mt: 2
                        }}
                    >
                        <AccordionSummary
                            expandIcon={<ExpandMoreIcon color="primary" />}
                            sx={{ px: 0 }}
                        >
                            <Typography variant="h6" color="primary">
                                {t('patients.medical_info_optional', 'Information Médicale (Optionnel)')}
                            </Typography>
                        </AccordionSummary>
                        <AccordionDetails sx={{ px: 0, pb: 2 }}>
                            <Grid container spacing={3}>
                                <Grid item xs={12} sm={4}>
                                    <TextField
                                        select
                                        fullWidth
                                        label={t('patients.blood_type', 'Groupe Sanguin')}
                                        name="blood_type"
                                        value={formData.blood_type}
                                        onChange={handleChange}
                                    >
                                        {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(type => (
                                            <MenuItem key={type} value={type}>{type}</MenuItem>
                                        ))}
                                    </TextField>
                                </Grid>
                                <Grid item xs={12} sm={8}>
                                    <TextField
                                        fullWidth
                                        label={t('patients.allergies', 'Allergies Connues')}
                                        name="allergies"
                                        value={formData.allergies}
                                        onChange={handleChange}
                                        placeholder="Ex: Pénicilline, Arachides..."
                                    />
                                </Grid>
                                <Grid item xs={12}>
                                    <TextField
                                        fullWidth
                                        label={t('patients.chronic', 'Conditions Chroniques / Antécédents')}
                                        name="chronic_conditions"
                                        value={formData.chronic_conditions}
                                        onChange={handleChange}
                                        multiline
                                        rows={2}
                                        placeholder="Ex: Diabète, Hypertension..."
                                    />
                                </Grid>
                            </Grid>
                        </AccordionDetails>
                    </Accordion>
                </CardContent>
            </Card>

            {/* Services Facturables Section */}
            <Card sx={{ borderRadius: 3, mb: 3 }}>
                <CardContent sx={{ p: 4 }}>
                    <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
                        <ReceiptIcon color="primary" />
                        <Typography variant="h6" color="primary">
                            Services à Facturer (Optionnel)
                        </Typography>
                        <Chip
                            label={`${selectedServices.length} sélectionné(s)`}
                            size="small"
                            color={selectedServices.length > 0 ? "success" : "default"}
                            variant="outlined"
                        />
                    </Stack>
                    <Divider sx={{ mb: 3 }} />

                    <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                        Sélectionnez les services/soins à facturer directement lors de la création du patient.
                        Une facture sera automatiquement générée avec les services sélectionnés.
                    </Typography>

                    <Grid container spacing={3}>
                        <Grid item xs={12} md={8}>
                            <Autocomplete
                                multiple
                                options={availableServices}
                                getOptionLabel={(option) => option.name}
                                value={selectedServices}
                                onChange={(event, newValue) => setSelectedServices(newValue)}
                                loading={loadingServices}
                                renderInput={(params) => (
                                    <TextField
                                        {...params}
                                        label="Sélectionner des services"
                                        placeholder="Choisir un service..."
                                        helperText="Recherchez et sélectionnez les services à facturer"
                                    />
                                )}
                                renderOption={(props, option) => (
                                    <li {...props}>
                                        <Box>
                                            <Typography variant="body1">{option.name}</Typography>
                                            <Typography variant="caption" color="text.secondary">
                                                {option.description} • {parseFloat(option.price) > 0 ? `${option.price} FCFA` : 'Prix non défini'}
                                            </Typography>
                                        </Box>
                                    </li>
                                )}
                                renderTags={(value, getTagProps) =>
                                    value.map((option, index) => (
                                        <Chip
                                            label={option.name}
                                            {...getTagProps({ index })}
                                            color="primary"
                                            variant="outlined"
                                        />
                                    ))
                                }
                            />
                        </Grid>

                        <Grid item xs={12} md={4}>
                            <FormControl fullWidth>
                                <InputLabel>Mode de Paiement</InputLabel>
                                <Select
                                    value={paymentMethod}
                                    label="Mode de Paiement"
                                    onChange={(e) => setPaymentMethod(e.target.value)}
                                >
                                    <MenuItem value="cash">Comptant</MenuItem>
                                    <MenuItem value="mobile_money">Mobile Money</MenuItem>
                                </Select>
                            </FormControl>
                        </Grid>

                        {selectedServices.length > 0 && (
                            <Grid item xs={12}>
                                <Paper variant="outlined" sx={{ p: 2 }}>
                                    <Typography variant="subtitle2" gutterBottom color="primary">
                                        Résumé de la Facturation
                                    </Typography>
                                    <TableContainer>
                                        <Table size="small">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell>Service</TableCell>
                                                    <TableCell align="right">Prix</TableCell>
                                                    <TableCell align="center">Action</TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {selectedServices.map((service, index) => (
                                                    <TableRow key={service.id}>
                                                        <TableCell>
                                                            <Typography variant="body2" fontWeight="medium">
                                                                {service.name}
                                                            </Typography>
                                                            {service.description && (
                                                                <Typography variant="caption" color="text.secondary">
                                                                    {service.description}
                                                                </Typography>
                                                            )}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            <Typography variant="body2" fontWeight="bold">
                                                                {parseFloat(service.price) > 0 ? `${service.price} FCFA` : '-'}
                                                            </Typography>
                                                        </TableCell>
                                                        <TableCell align="center">
                                                            <Tooltip title="Retirer">
                                                                <IconButton
                                                                    size="small"
                                                                    color="error"
                                                                    onClick={() => {
                                                                        setSelectedServices(prev =>
                                                                            prev.filter((_, i) => i !== index)
                                                                        );
                                                                    }}
                                                                >
                                                                    <DeleteIcon fontSize="small" />
                                                                </IconButton>
                                                            </Tooltip>
                                                        </TableCell>
                                                    </TableRow>
                                                ))}
                                                <TableRow>
                                                    <TableCell colSpan={1}>
                                                        <Typography variant="subtitle1" fontWeight="bold">
                                                            Total
                                                        </Typography>
                                                    </TableCell>
                                                    <TableCell align="right">
                                                        <Typography variant="h6" color="primary" fontWeight="bold">
                                                            {selectedServices.reduce((sum, s) => sum + (parseFloat(s.price) || 0), 0).toFixed(0)} FCFA
                                                        </Typography>
                                                    </TableCell>
                                                    <TableCell />
                                                </TableRow>
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                    <Typography variant="caption" color="text.secondary" sx={{ mt: 2, display: 'block' }}>
                                        Mode de paiement: <strong>{paymentMethod === 'cash' ? 'Comptant' : 'Mobile Money'}</strong>
                                    </Typography>
                                </Paper>
                            </Grid>
                        )}
                    </Grid>
                </CardContent>
            </Card>
        </Box>
    );
};

export default PatientForm;
