import React from 'react';

// Version simplifiée du PWA - temporairement désactivé
function PWAInstallPrompt() {
  return null;
}

export default PWAInstallPrompt;