import React from 'react';
import { useNavigate } from 'react-router-dom';
import {
    Box,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Typography,
    Chip,
    Card,
    CardContent,
    Skeleton,
    useTheme,
    useMediaQuery,
} from '@mui/material';
import { Receipt } from '@mui/icons-material';
import { formatDate } from '../../utils/formatters';
import useCurrency from '../../hooks/useCurrency';
import { useTranslation } from 'react-i18next';

function ClientInvoicesTable({ invoices, loading }) {
    const { t } = useTranslation(['clients', 'invoices', 'common']);
    const { format: formatCurrency } = useCurrency();
    const navigate = useNavigate();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('md'));

    const getStatusColor = (status) => {
        const colors = {
            draft: 'default',
            sent: 'info',
            paid: 'success',
            overdue: 'error',
            cancelled: 'default',
        };
        return colors[status] || 'default';
    };

    const getStatusLabel = (status) => {
        const labels = {
            draft: t('invoices:status.draft'),
            sent: t('invoices:status.sent'),
            paid: t('invoices:status.paid'),
            overdue: t('invoices:status.overdue'),
            cancelled: t('invoices:status.cancelled'),
        };
        return labels[status] || status;
    };

    if (loading) {
        return (
            <Box>
                {[1, 2, 3].map((i) => (
                    <Skeleton key={i} variant="rectangular" height={60} sx={{ mb: 1 }} />
                ))}
            </Box>
        );
    }

    if (!invoices || invoices.length === 0) {
        return (
            <Card>
                <CardContent>
                    <Box textAlign="center" py={4}>
                        <Receipt sx={{ fontSize: 60, color: 'text.secondary', mb: 2 }} />
                        <Typography variant="h6" color="text.secondary">
                            {t('clients:messages.noInvoicesForClient')}
                        </Typography>
                    </Box>
                </CardContent>
            </Card>
        );
    }

    // Mode Mobile - Cards
    if (isMobile) {
        return (
            <Box>
                {invoices.map((invoice) => (
                    <Card
                        key={invoice.id}
                        sx={{
                            mb: 1.5,
                            cursor: 'pointer',
                            transition: 'all 0.2s',
                            '&:hover': {
                                transform: 'translateY(-2px)',
                                boxShadow: 3,
                            },
                        }}
                        onClick={() => navigate(`/invoices/${invoice.id}`)}
                    >
                        <CardContent sx={{ p: 2 }}>
                            <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                                <Box>
                                    <Typography variant="body2" fontWeight="bold" color="primary">
                                        {invoice.invoice_number}
                                    </Typography>
                                    <Typography variant="caption" color="text.secondary">
                                        {invoice.title}
                                    </Typography>
                                </Box>
                                <Chip
                                    label={getStatusLabel(invoice.status)}
                                    color={getStatusColor(invoice.status)}
                                    size="small"
                                />
                            </Box>
                            <Box display="flex" justifyContent="space-between" alignItems="center">
                                <Typography variant="body2" fontWeight="bold">
                                    {formatCurrency(invoice.total_amount)}
                                </Typography>
                                <Typography variant="caption" color="text.secondary">
                                    {formatDate(invoice.created_at)}
                                </Typography>
                            </Box>
                        </CardContent>
                    </Card>
                ))}
            </Box>
        );
    }

    // Mode Desktop - Table
    return (
        <TableContainer component={Paper}>
            <Table>
                <TableHead>
                    <TableRow sx={{ backgroundColor: 'rgba(0,0,0,0.02)' }}>
                        <TableCell sx={{ fontWeight: 600 }}>{t('clients:table.invoiceNumber')}</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>{t('clients:table.title')}</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>{t('clients:table.status')}</TableCell>
                        <TableCell sx={{ fontWeight: 600 }} align="right">{t('clients:table.amount')}</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>{t('clients:table.creationDate')}</TableCell>
                        <TableCell sx={{ fontWeight: 600 }}>{t('clients:table.dueDate')}</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {invoices.map((invoice) => (
                        <TableRow
                            key={invoice.id}
                            hover
                            sx={{
                                cursor: 'pointer',
                                transition: 'all 0.2s',
                                '&:hover': {
                                    backgroundColor: 'rgba(25, 118, 210, 0.04)',
                                },
                            }}
                            onClick={() => navigate(`/invoices/${invoice.id}`)}
                        >
                            <TableCell>
                                <Typography
                                    variant="body2"
                                    color="primary"
                                    fontWeight="medium"
                                >
                                    {invoice.invoice_number}
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography variant="body2">
                                    {invoice.title}
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Chip
                                    label={getStatusLabel(invoice.status)}
                                    color={getStatusColor(invoice.status)}
                                    size="small"
                                />
                            </TableCell>
                            <TableCell align="right">
                                <Typography variant="body2" fontWeight="medium">
                                    {formatCurrency(invoice.total_amount)}
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography variant="body2" color="text.secondary">
                                    {formatDate(invoice.created_at)}
                                </Typography>
                            </TableCell>
                            <TableCell>
                                <Typography variant="body2" color="text.secondary">
                                    {formatDate(invoice.due_date)}
                                </Typography>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}

export default ClientInvoicesTable;

